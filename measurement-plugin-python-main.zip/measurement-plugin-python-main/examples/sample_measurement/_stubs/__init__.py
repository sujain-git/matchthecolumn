"""Stubs for sample_measurement's color enum."""

"""Stubs for non_streaming_data_measurement's color enum."""

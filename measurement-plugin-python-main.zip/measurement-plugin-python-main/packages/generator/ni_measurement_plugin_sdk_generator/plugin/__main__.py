"""Creates a measurement through use of __init__.py."""

from ni_measurement_plugin_sdk_generator.plugin import create_measurement

create_measurement()

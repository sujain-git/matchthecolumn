"""Contains test assets."""

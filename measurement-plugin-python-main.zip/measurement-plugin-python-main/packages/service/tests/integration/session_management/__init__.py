"""Integration tests for driver-specific session management APIs."""

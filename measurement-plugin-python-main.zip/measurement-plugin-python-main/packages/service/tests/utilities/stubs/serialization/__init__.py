"""Auto generated gRPC files for serialization tests."""

"""Auto generated gRPC files for niswitch test measurement."""

"""Auto generated gRPC files for nidmm test measurement."""

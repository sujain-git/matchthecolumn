"""Auto generated gRPC files for nidaqmx test measurement."""

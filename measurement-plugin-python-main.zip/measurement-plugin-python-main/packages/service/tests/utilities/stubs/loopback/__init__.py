"""Auto generated gRPC files for loopback measurement."""

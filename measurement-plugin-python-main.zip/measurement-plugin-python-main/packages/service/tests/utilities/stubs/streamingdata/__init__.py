"""Auto generated gRPC files for streaming data measurement."""

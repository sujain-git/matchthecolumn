"""Auto generated gRPC files for nifgen test measurement."""

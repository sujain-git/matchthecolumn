"""Auto generated gRPC files for niscope test measurement."""

"""Auto generated gRPC files for nidigital test measurement."""

"""Auto generated gRPC files for nidcpower test measurement."""

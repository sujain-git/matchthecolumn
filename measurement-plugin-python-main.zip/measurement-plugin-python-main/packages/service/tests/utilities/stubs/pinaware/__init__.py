"""Auto generated gRPC files for pin-aware measurement."""

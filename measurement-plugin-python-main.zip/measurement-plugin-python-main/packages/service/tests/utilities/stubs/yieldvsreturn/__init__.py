"""Auto generated gRPC files for yield vs. return measurement."""

"""Unit tests for ni_measurement_plugin_sdk_service.measurement."""

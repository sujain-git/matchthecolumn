"""Constants for annotations."""

ENUM_VALUES_KEY = "ni/enum.values"
TYPE_SPECIALIZATION_KEY = "ni/type_specialization"
SERVICE_PROGRAMMINGLANGUAGE_KEY = "ni/service.programminglanguage"

"""Public API for accessing the NI Pin Map Service."""

from ni_measurement_plugin_sdk_service.pin_map._client import PinMapClient

__all__ = ["PinMapClient"]

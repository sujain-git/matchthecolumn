---
name: User story
about: (DEV TEAM ONLY) A small chunk of work to be done
title: '(Fully descriptive title)'
labels: 'user story,triage'
---

<!-- Ensure the title can be understood without the parent item's context, e.g. "nimble-button Angular wrapper" rather than just "Angular wrapper" -->

## User Story
